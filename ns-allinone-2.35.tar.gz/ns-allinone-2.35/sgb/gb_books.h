/*1:*/
#line 16 "gb_books.w"

extern Graph*book();
extern Graph*bi_book();

/*:1*//*6:*/
#line 127 "gb_books.w"

extern long chapters;
extern char*chap_name[];

/*:6*//*18:*/
#line 334 "gb_books.w"

#define desc  z.S 
#define in_count  y.I
#define out_count  x.I
#define short_code  u.I

/*:18*//*23:*/
#line 468 "gb_books.w"

#define chap_no a.I 

/*:23*/
